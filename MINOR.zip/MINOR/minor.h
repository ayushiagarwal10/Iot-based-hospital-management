const char html_code[] PROGMEM = R"(
<html>
<head>
  <title>Minor Project</title>
  <style>
  input[type=submit]{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 16px 32px;
    text-decoration: none;
    margin: 2px;
    cursor: pointer;}
  </style>
</head>
<body>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <center>
  <form action="data" id="form" name="form">
  
  <button name="UP" id = "UP" value=0 onclick="goUP();">FORWARD</button>
  
  <br><br>
  <button name="LEFT" id = "LEFT" value=0 onclick="goLEFT();">LEFT</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <button name="RIGHT" id = "RIGHT" value=0 onclick="goRIGHT();">RIGHT</button>
  
  <br><br>  
  <button name="DOWN" id = "DOWN" value=0 onclick="goDOWN();">BACKWARD</button>
    
</form>
  <scipt>
  function goUP()
        {
          if(document.form.UP.value==0)
            {
              document.form.UP.value =1
              
            }
            else
            {
            document.form.UP.value =0
             }
        }

  function goLEFT()
        {
          if(document.form.LEFT.value==0)
            {
              document.form.LEFT.value =1
            }
            else
            {
            document.form.LEFT.value =0
             }
        }
   function goRIGHT()
        {
          if(document.form.RIGHT.value==0)
            {
              document.form.RIGHT.value =1
              
            }
            else
            {
            document.form.RIGHT.value =0
             }
        }
  function goDOWN()
        {
          if(document.form.DOWN.value==0)
            {
              document.form.DOWN.value =1
              
            }
            else
            {
            document.form.DOWN.value =0
             }
        }
  </script>
  </center>
</body>
</html>
)";
